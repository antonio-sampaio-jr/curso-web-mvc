package unidade3;

public class Calc 
{
	public int cubo(int n){
	    return (n*n*n);
	}
}
