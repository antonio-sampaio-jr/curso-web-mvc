const myColors = require("colors/safe");

console.log(myColors.yellow('hello')); 
console.log(myColors.red.underline('i like cake and pies'))
console.log(myColors.inverse('inverse the color')); 
console.log(myColors.rainbow('OMG Rainbows!')); 
console.log(myColors.trap('Run the trap')); 
